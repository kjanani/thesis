Many people have contributed to this effort. 
Any ommissions are not intentional.

- [Novimir Pablant](mailto:antoniuk@physics.ucsd.edu) (2009-2010)
- [Diwaker Gupta](mailto:diwaker@floatingsun.net) (2008-2009)
- Macneil Shonle (2009)
- Himanshu Khatri (2009)
- evilkartman (2009)
- David Collins (2009)
- Jason Bandlow (2008)
- Ross Richardson (2008)
- Dana Dahlstorm
- Will Brockman
- John Eggers
- John Farina
- Skip Garibaldi
- Erza Hallck
- Mike Zabrocki
- [Blaise B. Frederick](mailto:frederic@imasun.lbl.gov) (1994)
- Many other UCSD graduate students 
  (especially from the Math department)

Original ucthesis.sty by:
- Ethan V. Munson (1994)

Based on report.sty (1992) by:
- Frank Mittlebach (1992)
- Rainer Schopf (1992)
